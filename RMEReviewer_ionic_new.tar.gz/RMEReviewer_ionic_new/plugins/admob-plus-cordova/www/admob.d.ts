import { AdMob } from "./index";
declare const admob: AdMob;
export default admob;
