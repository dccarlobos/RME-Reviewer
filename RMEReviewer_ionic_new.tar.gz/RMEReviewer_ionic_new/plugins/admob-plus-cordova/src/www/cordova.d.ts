/// <reference types="cordova-plus/types" />
